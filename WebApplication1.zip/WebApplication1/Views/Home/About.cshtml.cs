using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.Home
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
